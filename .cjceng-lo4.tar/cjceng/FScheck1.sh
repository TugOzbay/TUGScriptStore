#!/bin/bash
#
# By Tugrul Ozbay CJCIT June 2015
# Note: This script can be used to warn admin that
# the file system is getting full of shit
#
# By Tugrul Ozbay CJCIT June 2015
# 
# set -x
#
DT=`date | awk '{print $2"-"$3 " "$4}'`
HOSTN=`hostname`;
SEND="stats@cjcit.com";
# RECV="cjcengineering_cjcit@cjcit.com";
RECV="tugrul.ozbay@cjcit.com";
SUBJ="Disk usage on $HOSTN";
MLDR="/data01/home/cjcadmin/scripts/mailAlert";
Pct=95
#
export DT
echo "Testing data $HOSTN $RECV $SUBJ $Pct $DT";
#
if [ -f /tmp/FScheck.log ]
then
	mv /tmp/FScheck.log /tmp/FScheck.log.1
fi
#

for disk in \/dev\/dsk\/c0t0d0s0  \/tmp  \/var  \/data01
do
	# echo "checking ...	$disk" >>  /tmp/FScheck.log
    	if [ `df -kl|grep "$disk"|awk '{print $5}'|grep -v Capacity|sed 's/.$//'| head -1` -lt ${Pct} ]
    	 then
		echo "All ok - less than $Pct % usage on $disk today $DT"
		echo "All ok - less than $Pct % usage on $disk today $DT" >> /tmp/FScheck.log
		echo "------------------------------------------------------------------------------------------  " >> /tmp/FScheck.log
		echo "------------------------------------------------------------------------------------------  " >> /tmp/FScheck.log
    	 fi
done

for disk in \/dev\/dsk\/c0t0d0s0  \/tmp  \/var  \/data01
do
#	echo "checking ...	$disk" >>  /tmp/FScheck.log
 	if [ `df -kl|grep "$disk"|awk '{print $5}'|grep -v Capacity|sed 's/.$//'|head -1` -ge ${Pct} ]
         then
		echo "------------------------------------------------------------------------------------------  " >> /tmp/FScheck.log
		echo "** PLS CHECK ** - over $Pct % disk usage on ===>  $disk today $DT " >> /tmp/FScheck.log
		echo "------------------------------------------------------------------------------------------  " >> /tmp/FScheck.log
    	fi
done
	sleep 60
	./mailz.pl
